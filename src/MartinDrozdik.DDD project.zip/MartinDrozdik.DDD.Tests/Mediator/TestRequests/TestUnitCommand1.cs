﻿using MartinDrozdik.DDD.Mediator.Commands;

namespace MartinDrozdik.DDD.Tests.Mediator.TestRequests;

internal class TestUnitCommand1 : ICommand
{
    public int HandleIncrement { get; set; }

    public void AssertHandled(int handleCount = 1)
    {
        Assert.Equal(handleCount, HandleIncrement);
    }
}

internal class TestUnitCommand1Handler : ICommandHandler<TestUnitCommand1>
{
    public Task HandleAsync(TestUnitCommand1 command, CancellationToken cancellationToken)
    {
        command.HandleIncrement++;
        return Task.CompletedTask;
    }
}
